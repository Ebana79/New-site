function  Welcom () {
    alert("Bienvenue sur somba shop")
}

confirm("Soyez prêt à depenser sur Somba shop");

let somme = prompt("Votre nom svp");

function AFF() {
    alert('Bonjour ' + somme);
    document.bgcolor = '#fff';
}
//Prend le relet et customize cette page couz moi je l'ai generer par chatgpt mais vu que je pas très douer au niveau de
/*  HTML et CSS je te laisse mieu editer cette page et moi je continue mes cours sur le javascript */
//Ps change l'adresse des images dans le fichier html